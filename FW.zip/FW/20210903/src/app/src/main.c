/****************************************************************************************************************************/
/*  Filename    : main.c                                                                             												*/
/*  Component name : 3S_BMS                                                                                                 */
/*  Abstract    : Header file for external                                                                                  */
/*  Copyright(C): 2021 by DW                                                                           					          	*/
/*  Author      : DengWei                                                                                                   */
/*  Revision    : 00.01                                                                                                     */
/*  Revision history : 00.01 | 2021/08/29 | First Release 																													        */
/*                   : 01.00 | 2021/09/03 | Fix Watch dog bug                                                   		 	      */
/*                   : 02.00 | 2021/xx/xx |                                                                                 */
/*                   : 02.01 | 2021/xx/xx |                                                                                 */
/*                   : 03.00 | 2021/xx/xx |                                                                                 */
/*  Date of creation : 2021/05/02                                                                                           */
/*     Last modified : 2021/08/29                                                                                           */
/****************************************************************************************************************************/
#include <stdio.h>
#include "stm32f10x.h"
#include "SYSTICK.h"
#include "config.h"
#include "SEGGER_RTT.h"
#include "usart.h"
#include "IO_CTRL.h"
#include "i2c1.h"
#include "timer.h"
#include "spi.h"
#include "BQ76920.h"
#include "math.h"
#include "wdg.h"
#include "adc.h"
#include "Command.h"


/****************************************************************************************************************************/
/* Function: main-----------------------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------------------------------------------------*/
/* Paramters: void----------------------------------------------------------------------------------------------------------*/
/* Return:None--------------------------------------------------------------------------------------------------------------*/
/* Statement: All right reserved by DW,Do not use for commercial purposes --------------------------------------------------*/
/****************************************************************************************************************************/

extern u8 USART1_RX_BUF[10]; 
extern u8 USART1_RX_CNT;
extern u8 Uart_Recive_Flag;
unsigned char BMS_DATA_FLAG;
extern char Have_Charge_Voltage;
extern char DET_Pin;
extern int Timer_250mS_Flag;
extern int OT_Alarm_flag,UT_Alarm_flag,UV_Alarm_flag,OV_Alarm_flag,SCD_Alarm_flag,OCD_Alarm_flag;
extern int NO_Current_15min_Flag;
extern int One_Second_Flag,Count,Due_Count;//Using this flag for charger in detection.
extern int Battery_Value[50];//Battery Information

void Temp_ALERT(void);


/* ------------------------------------------------------------------
Current Measure
Voltage Detection
Tempereture Measure
Threhold Protection
Battery Status Control
J-LNIK Viwer-RTT-Debug Fuction
UART
Watch Dog
-------------------------------------------------------------------*/
int main(void)              
{   
	SYSTICK_Init(); 
	uart_init(115200);	
	IO_CTRL_Config(); 			//IO setting
	DET_Pin_Init();					//DET-PIN Initial
	I2C1_Configuration();   //BQ76920's IIC setting��
	BQ76920_config(); 			//AFE setting
	delay_ms(100);   
	/*Timer interepter set to 1S. using this timer for UART handle*/
	TIM2_Config(1000-1,7199);//1000mS
	/*Timer3 for Battery Status switching.*/
	TIM3_Config(250-1,7199);//250mS
	
	IWDG_Init(6,9999);      //watch dog setting
	
	
	for(;;)  //Initial Information
	{  
	UartSend("This is a 3S1P Lithium Battery Pack!\r\n");
	UartSend("Made by DW!\r\n");
	UartSend("U R now watching the PACK INFO by this window\r\n");	
	break;	
	}
	
	for(;;)//Main loop
	{
		IWDG_Feed();	  //watch dog
		RTT_Handle(); 	//Using for J-Link Viewer
		Get_Update_Data(); //GET bq76920 Data
  //Uart_Receive_Data_Handler();  //enable this function if you need 

/*----------------------------------------------------------*/
			//Error handle about One_Second_Flag
			if(One_Second_Flag>3){
			One_Second_Flag=0;
			}	
/*----------------------------------------------------------*/			
			
		if(Timer_250mS_Flag==1){
			Timer_250mS_Flag=0;	
		//	UartSend("250mS----\r\n");//for Timer flag debug
			Battery_Switching_Command();
			}
					
		//Battery_Switching_Command();
		if(Battery_Value[9] < 40){		
			Due_Count++;
			}else if(Battery_Value[9] >= 40){
			Due_Count=0;
			}					
		if(Due_Count>=900){
				NO_Current_15min_Flag = 1;	
				Due_Count=0;														
				}else{  						
							NO_Current_15min_Flag=0;
							
							Due_Count=0;
							}	

			//Battery_Switching_Command
		 
		 
		 
	}

}

//*********************************************************************************************************



