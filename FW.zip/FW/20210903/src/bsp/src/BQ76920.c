#include "BQ76920.h"
#include "SYSTICK.h" 
#include "i2c1.h"
#include "usart.h"
#include "math.h"
#include "string.h"
#include "IO_CTRL.h"
#include "wdg.h"

int ADC_offset,GAIN,SOC;
int Battery_Value[50]={0};//Battery Information
float ADC_GAIN = 0;

//char ACK[50]={0xAA,0x01};  //useless


//CRC8 
unsigned char CRC8(unsigned char *ptr, unsigned char len,unsigned char key)
{
	unsigned char i;
	unsigned char crc=0;
	while(len--!=0)
	{
		for(i=0x80; i!=0; i/=2)
		{
			if((crc & 0x80) != 0)
			{
				crc *= 2;
				crc ^= key;
			}
			else
				crc *= 2;

			if((*ptr & i)!=0)
				crc ^= key;
		}
		ptr++;
	}
	return(crc);
}


/*****************************
file:BQData.c
decription:
   1.�ɼ�BQ76930��14λADC�������ƫ�õ�ѹ:void get_offset(void)
   2.�ɼ������ѹ:void Get_Batteryx(void),����xȡֵ1-10��
   3.BQ76930��ʼ�� void BQ_config(void)
   4.��ȡBQ76930�Ĵ���ֵ�� void readbqstate(void)
   5.
******************************/
/***********************
fuction:void get_offset(void)
************************/


void Get_offset(void)
{
 unsigned char gain[2];
 
 gain[0]=IIC1_read_one_byte(ADCGAIN1);//Get address of ADC_GAIN1	0x50
 gain[1]=IIC1_read_one_byte(ADCGAIN2);//Get address of ADC_GAIN2	0x59
 ADC_GAIN = ((gain[0]&0x0c)<<1)+((gain[1]&0xe0)>>5);//12uV
 ADC_offset=IIC1_read_one_byte(ADCOFFSET);//45mV   address 0x51
//GAIN= 365��V/LSB+(ADCGAIN<4:0>in decimal)��(1��V/LSB)  From datasheet
 GAIN = 365+ADC_GAIN;//GAIN=377uV
}
/****************************************
fuction: void Get_Battery1(void)
description:��ȡ��1�ŵ����ص�ѹ
Parameters:batterylval[0],battery1val[1];
******************************************/
void BQ76920_config(void)
{
	  Wake_Up_AFE();
    BQ76920_Init();
	  Get_offset();
    OVP_UVP_Protection();	//Over Voltage	&	Under Voltage protection
    OCD_SCD_PROTECT();		//Over Current & Short Protection
	   	 
	  IIC1_write_one_byte_CRC(SYS_STAT,0xFF);  
}

/**************************************************************************
Description	:Get the state of BQ76920. 
Remark			:#define SYS_CTRL2 0x05
Date				:21/07/26 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/
void BQ76920_Init(void)
{

   AFE_Config();//
}
/**************************************************************************
Description	:Get the state of BQ76920. 
Remark			:#define SYS_CTRL2 0x05
Date				:21/07/26 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/
void OVP_UVP_Protection(void)
{
    OVP_UVP_Detection_Condition();	
}

/**************************************************************************
Description	:wake up BQ76920. 
Remark			:
Date				:
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/
//void Wake_Up_Device(void)
//{
//	  MCU_WAKE_BQ_ONOFF(Bit_SET);   //wake up BQ76920  Bit_SET=1; ö�ٱ���
//	  delay_ms(100);
//	  MCU_WAKE_BQ_ONOFF(Bit_RESET);	 
//}


//void SHIP_ALL_DEVICE(void)
//{
//	IIC1_write_one_byte_CRC(SYS_STAT,0xFF);	
//  //SHIP_1_BQ769(); 
//  MCU_KZ_QB_POWER_ONOFF(Bit_RESET);

//}


 
 
 void Get_Battery1(void)
{
  unsigned int Read_Cell_Voltage[2];
  short Cell_Voltage;
	
  Read_Cell_Voltage[1] = IIC1_read_one_byte(0x0c); 	// cell's register address (High)
  Read_Cell_Voltage[0] = IIC1_read_one_byte(0x0d);	// cell's register address (Low)
	/*-----------------------------------------------------------------------------------
	  GAIN(��V/LSB)
		OFFSET(mV)
		got this Formula from datasheet -> V(cell)=GAIN x ADC(cell) + OFFSET    (ADC is in Decimal)
	------------------------------------------------------------------------------------*/ 
  Cell_Voltage= Read_Cell_Voltage[1];
  Cell_Voltage= (Cell_Voltage << 8) |Read_Cell_Voltage[0];  // Keep MSB,Then OR LSB.  
  Cell_Voltage=((Cell_Voltage*GAIN)/1000)+ADC_offset;
  Battery_Value[0]=Cell_Voltage;	//Use this value for SOC
	
  //battery1val[1]=(char)(Battery_Value1 >> 8);  //separate the data which read from resister and Keep the high bit.
  //battery1val[0]=(char)(Battery_Value1 & 0x00FF);
	
	//ACK[2]=battery1val[1];	//Provide this value to Upper monitor
	//ACK[3]=battery1val[0];	//Provide this value to Upper monitor

}


/****************************************
fuction: void Get_Battery2(void)
description:��ȡ��2�ŵ����ص�ѹ
Parameters:battery2val[0],battery2val[1];
******************************************/
void Get_Battery2(void)
{
 
  char Read_Cell_Voltage[2];
  short Cell_Voltage;

	
  Read_Cell_Voltage[1]=IIC1_read_one_byte(0x0e);
  Read_Cell_Voltage[0]=IIC1_read_one_byte(0x0f);
 
  Cell_Voltage= Read_Cell_Voltage[1];
  Cell_Voltage= (Cell_Voltage << 8) |Read_Cell_Voltage[0];
   
  Cell_Voltage=((Cell_Voltage*GAIN)/1000)+ADC_offset;
	Battery_Value[1]=Cell_Voltage;

	
}
/****************************************
fuction: void Get_Battery3(void)
description:��ȡ��3�ŵ����ص�ѹ
Parameters:battery3val[0],battery3val[1];
******************************************/
void Get_Battery3(void)
{
 
  char Read_Cell_Voltage[2];
  int Cell_Voltage ;
	
  Read_Cell_Voltage[1]=IIC1_read_one_byte(0x10);
  Read_Cell_Voltage[0]=IIC1_read_one_byte(0x11);
 
  Cell_Voltage= Read_Cell_Voltage[1];
  Cell_Voltage= (Cell_Voltage << 8) |Read_Cell_Voltage[0];
  Cell_Voltage=((Cell_Voltage*GAIN)/1000)+ADC_offset;
	Battery_Value[2]=Cell_Voltage;
	
}
/****************************************
fuction: void Get_Battery4(void)
description:��ȡ��4�ŵ����ص�ѹ
Parameters:battery4val[0],battery4val[1];
******************************************/
void Get_Battery4(void)
{
  char Read_Cell_Voltage[2];
  int Cell_Voltage ;
 
  Read_Cell_Voltage[1]=IIC1_read_one_byte(0x12);
  Read_Cell_Voltage[0]=IIC1_read_one_byte(0x13);
 
  Cell_Voltage= Read_Cell_Voltage[1];
  Cell_Voltage= (Cell_Voltage << 8) |Read_Cell_Voltage[0];
  Cell_Voltage=((Cell_Voltage*GAIN)/1000)+ADC_offset;

	Battery_Value[3]=Cell_Voltage;

}
/****************************************
fuction: void Get_Battery5(void)
description:��ȡ��5�ŵ����ص�ѹ
Parameters:battery5val[0],battery5val[1];
******************************************/
void Get_Battery5(void)
{
	char Read_Cell_Voltage[2];
  short Cell_Voltage ;
	
  Read_Cell_Voltage[1]=IIC1_read_one_byte(0x14);
  Read_Cell_Voltage[0]=IIC1_read_one_byte(0x15);
 
  Cell_Voltage= Read_Cell_Voltage[1];
  Cell_Voltage= (Cell_Voltage << 8) |Read_Cell_Voltage[0];
  Cell_Voltage=((Cell_Voltage*GAIN)/1000)+ADC_offset;
	Battery_Value[4]=Cell_Voltage;

}

/****************************
��ȡ���е�ص��ܵ�ѹֵ
 *****************************/

void Get_Update_ALL_Data(void)
{
	int i,Sum_val;
  for(i=0;i<6;i++)
	{
	   Sum_val+= Battery_Value[i];
	}
	Battery_Value[6] = Sum_val;	
}

//RSOC��һ������Ҫ���ݲ�ͬ��оȥ������ѧģ�ͣ�Ȼ��Բ�ͬ�ķŵ籶�ʻ��зŵ�����
//���ָ��ӵ��������м��㣬Ȼ������ʵ��ֵ��SOC���������Battery_Value[6]��
//�˴����ü򵥵Ŀ�·��ѹ������ʾ�������������ʵRSOCֵ��
//����Ȥ��С�������Լ��о�һ���������Matlab���еĿ���з��������ѧ��ʽŶ
void Get_SOC(void)
{
	
  if(	Battery_Value[6] >(4100*3))
  {
	SOC=100;
	}
	else if((Battery_Value[6]>(4000*3))&&(Battery_Value[6]<(4100*3))){SOC=90;}
	else if((Battery_Value[6]>(3900*3))&&(Battery_Value[6]<(4000*3))){SOC=80;}
	else if((Battery_Value[6]>(3800*3))&&(Battery_Value[6]<(3900*3))){SOC=70;}
	else if((Battery_Value[6]>(3700*3))&&(Battery_Value[6]<(3800*3))){SOC=60;}
	else if((Battery_Value[6]>(3600*3))&&(Battery_Value[6]<(3700*3))){SOC=50;}
	else if((Battery_Value[6]>(3500*3))&&(Battery_Value[6]<(3600*3))){SOC=40;}
	else if((Battery_Value[6]>(3400*3))&&(Battery_Value[6]<(3500*3))){SOC=30;}
	else if((Battery_Value[6]>(3300*3))&&(Battery_Value[6]<(3400*3))){SOC=20;}
	else if((Battery_Value[6]>(3200*3))&&(Battery_Value[6]<(3300*3))){SOC=10;}
	else if((Battery_Value[6]>(3100*3))&&(Battery_Value[6]<(3200*3))){SOC=5;}
	else if((Battery_Value[6]>(3000*3))&&(Battery_Value[6]<(3100*3))){SOC=0;} 
	Battery_Value[32] = SOC;
	Battery_Value[7] = SOC;

}


//OVP+UVP protection 
//0VP 4.23V   Release 4.1V
//UVP 2.75V   Release 3.0V
//When OVP Occur , the Charge FET Closed.
//When UVP Occur, The Discharge FET Closed
void OVP_UVP_Detection_Condition(void)
{
  unsigned char OVTrig_Val,UVTrig_Val;
//GAIN= 365��V/LSB+(ADCGAIN<4:0>in decimal)��(1��V/LSB)  From datasheet
//GAIN = 365+ADC_GAIN;//GAIN=377uV
  float Gain = 0.377;
	//OV_TRIP_FULL = (OV �C ADCOFFSET) �� ADCGAIN
  OVTrig_Val = (unsigned char)((((unsigned int)((OVPThreshold - ADC_offset)/Gain + 0.5 ) )>>4) &0xFF); //Use 0.5 to make it into integer
	//UV_TRIP_FULL = (UV �C ADCOFFSET) �� ADCGAIN
  UVTrig_Val = (unsigned char)((((unsigned int)((UVPThreshold - ADC_offset)/Gain + 0.5 ) )>>4) &0xFF);
	
  IIC1_write_one_byte_CRC(OV_TRIP,OVTrig_Val);//Write OVP Condition
  IIC1_write_one_byte_CRC(UV_TRIP,UVTrig_Val);//Write UVP Condition
 }

 
 
// over current and Short protection	
 //19.5A  400uS
 //12A 1280mS
void OCD_SCD_PROTECT(void) 
{
// 0x1D--->  0001,1101   which means Bits 4~3: 1~1 -->short delay time is 400us
// 78mV / 4m�� = 19.5A 
IIC1_write_one_byte_CRC(PROTECT1,0x19);//Short Detection current is 19.5A(SRN-SRP78mV),RSNS=0.
//0x7F--->  0111,1111   which means Bits 6~4: 1~1~1 -->Delay time is 1280ms.	
IIC1_write_one_byte_CRC(PROTECT2,0x7F);//Setting OSD to 12A(SRN-SRP50mV).
	
}


/****************************************
fuction: void BQ_1_config(void)
description:BQ76930��ʼ��
Parameters: None
 //0x04�Ĵ���0x19��ӦSCD��ʱ70uS���ŵ��·��ѹ33mV��
 //0x05�Ĵ������ü�����Ϊ1-shotģʽ��
 //0x06�Ĵ���0x39��ӦOCD����ʱʱ��80mS���ŵ������ѹ33mV����·�͹�����Ӧ��������60A.
#define SYS_STAT 0x00
#define CELLBAL1 0x01
#define CELLBAL2 0x02
#define SYS_CTRL1 0x04
#define SYS_CTRL2 0x05
#define PROTECT1 0x06
#define PROTECT2 0x07
#define PROTECT3 0x08
#define OV_TRIP 0x09
#define UV_TRIP 0x0A
#define CC_CFG  0x0B
******************************************/
unsigned char BQ769_INITAdd[11]={SYS_STAT,CELLBAL1,CELLBAL2,SYS_CTRL1,SYS_CTRL2,PROTECT1,PROTECT2,PROTECT3,OV_TRIP,UV_TRIP,CC_CFG};
unsigned char BQ769_INITdata[11]={0xFF,     0x00,    0x00,    0x18,    0x43,      0x00,     0x00,    0x00,    0x00,   0x00,  0x19};

void AFE_Config(void)
{
   char i;
   for(i=0;i<11;i++)
    {
			delay_ms(50);
			IIC1_write_one_byte_CRC(BQ769_INITAdd[i],BQ769_INITdata[i]);
    }
}


/****************************************
fuction:void SHIP_1_BQ769(void)
description:BQ76930����͹���ģʽ
Parameters: None
******************************************/
void Switch_To_Ship_Mode(void)
{
  IIC1_write_one_byte_CRC(SYS_CTRL1,0x19); //01
  delay_ms(20);
  IIC1_write_one_byte_CRC(SYS_CTRL1,0x1a); //10
 }

 

/****************************************
fuction:void SHIP_2_BQ769(void)
description:��BQ76930�͹���ģʽ����
Parameters: None
******************************************/
void Wake_Up_AFE(void)
{
		 
   MCU_WAKE_BQ_ONOFF(Bit_SET);
	 delay_ms(100);
	 MCU_WAKE_BQ_ONOFF(Bit_RESET);
	 //NVIC_SystemReset();                       //����
 }

 /****************************************
fuction: void Get_BQCurrent(void)
description:BQ76930�����������������谴4m������
Parameters: None
******************************************/
 void Get_BQ_Current(void)
 {	 
   unsigned char readCurrentbuf[2];
	 unsigned int    Currentbufval;
	 float  Currentval;
	 
		// unsigned char Currentbuf[1];
		//IIC1_write_one_byte_CRC(SYS_CTRL2,0X23);
	 readCurrentbuf[1]=IIC1_read_one_byte(CC_HI_BYTE); //Read current MSB
   readCurrentbuf[0]=IIC1_read_one_byte(CC_LO_BYTE);	//LSB
   Currentbufval = readCurrentbuf[1];
   Currentbufval = (Currentbufval << 8)|readCurrentbuf[0];
	 /*This is Charge current ,Positive direction*/
	 if(  Currentbufval <= 0x7D00 )   //Charge 0x0001 TO 0x7D00
	 {	 
/*	CC Reading(in��V)=[16-bit 2's Complement Value]��(8.44��V/LSB)		*/  //����  
/*  After Mluti with 8.44, the result is Voltage.then devide 4mOHM resister, then get the current value */
	 Currentval = (Currentbufval*2.11);    //SR=4m��,8.44��V/4m��=2.11 Currentval Unit is mA.
   Battery_Value[9]=Currentval;
//IIC1_write_one_byte_CRC(SYS_STAT,0x80); 
	 }
	  /*This is Discharge current ,Nagetive direction Which means we did not have discharge direction*/
   else // Discharge current handle Formula. from 0x7D00 TO 0xFFFF
	 {		  
		Currentval = ((0XFFFF - Currentbufval )*2.11);  //next time,fix this point.
		Battery_Value[9]=Currentval;
 
	 }		 	 
 }
 /****************************************
fuction: void Get_BQ_1_Temp(void)
description:BQ76930 103AT�¶Ȳ���
Parameters: None
******************************************/

 float  Temperature;
 void Get_Temp_FromAFE(void)
 {
		int		Thermistor_Value;
		float Rp=10000;
		float T2=273.15+25;
		float Bx=3350;
		float Ka=273.15;
		unsigned char Read_Tem_Buf[2];
	 
		Read_Tem_Buf[1]=IIC1_read_one_byte(TS1_HI_BYTE);
		Read_Tem_Buf[0]=IIC1_read_one_byte(TS1_LO_BYTE);
	 
		Thermistor_Value = (Read_Tem_Buf[1] << 8 ) | Read_Tem_Buf[0];
/*		VTSX   =  (ADC  in  Decimal)  x  382  ��V/LSB       	*/                                                                                                                                                                                                                                                                    
/*		RTS = (10,000 �� VTSX) �� (3.3 �C VTSX)								*/
		Thermistor_Value = (10000*(Thermistor_Value*382/1000))/(3300-(Thermistor_Value*382/1000)); 
	 
/*		T1=1/��ln��Rt/R��/B+1/T2��	  //this is depend on Thermistor specification	*/
		Temperature = 1/(1/T2+(log(Thermistor_Value/Rp))/Bx)- Ka + 0.5; // �������� +0.5
		Battery_Value[8] = Temperature;

 }

 //send the battery information to monitor��PC��
 void Update_val(void)
{
  char NEW[50]={0};
//--------������λ����ʾ�����飬�������еĵ����Ϣ��-----//
//	  for(n=0;n<21;n++)
//		{
//			USART_SendData(USART1, ACK[n]); //����һ���ֽ�����
//			delay_ms(10);		
//		}
//-------------------------------------------------------//		
  delay_ms(50);
		
	sprintf(NEW,"Cell_1: %s%d%s ,1);\r\n","��һ�ڵ�ص�ѹΪ:",Battery_Value[0],"mV"); 
  UartSend(NEW); 
  
	delay_ms(50); 

	sprintf(NEW,"Cell_2: %s%d%s ,2);\r\n","�ڶ��ڵ�ص�ѹΪ:",Battery_Value[1],"mV"); 
  UartSend(NEW); 
		
  delay_ms(50);
	
	sprintf(NEW,"Cell_3: %s%d%s ,3);\r\n","�����ڵ�ص�ѹΪ:",Battery_Value[4],"mV"); //��ΪӲ��short���ţ�ʵ�ʶ�ȡ����ڵ�ص�ѹ
  UartSend(NEW); 

  
	delay_ms(50); 
	sprintf(NEW,"Vpack: %s%d%s',4);\r\n","����ܵ�ѹΪ:",Battery_Value[6],"mV");
	
  UartSend(NEW);   
  delay_ms(50); 
	sprintf(NEW,"RSOC: %s%d%s');\r\n","���SOCΪ:",Battery_Value[32],"%"); 
  UartSend(NEW); 
  
	delay_ms(50); 
	sprintf(NEW,"Temp Of Cell: %s%.2f%s');\r\n","����¶�Ϊ:",Temperature,"��"); 
  UartSend(NEW); 

	delay_ms(50); 
	sprintf(NEW,"Current: %s%d%s');\r\n","��ǰ����Ϊ:",Battery_Value[9],"mA"); 
  UartSend(NEW); 
  
	delay_ms(50);
	
	sprintf(NEW,"Logo: %s');\r\n","D W "); 
  UartSend(NEW);
	
	delay_ms(50);
	IWDG_Feed();

}


//�����˵�ص�״̬
//
unsigned char BMS_sta,DSG_STA,CHG_STA,DSG_STA_FLAG,CHG_STA_FLAG;	

/**************************************************************************
Description	:Get the state of BQ76920. 
Remark			:#define SYS_CTRL2 0x05
Date				:21/07/26 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/ 
void BMS_STA(void)
{
		BMS_sta = IIC1_read_one_byte(SYS_CTRL2);//IIC read the state of the battery.
		DSG_STA = BMS_sta&0x02;//0000 , 0010  bit1 == 1, Discharge ON, or Discharge off.
		CHG_STA = BMS_sta&0x01;//0000 , 0010  bit0 == 1, Charge ON,or Charge off.

}

/**************************************************************************
Description	:Only open charge FET.
Remark			:
Date				:21/07/26 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/ 
 void Only_Open_CHG(void)
{
		BMS_STA();//get the state of the Battery.
		if(DSG_STA!=0){
		IIC1_write_one_byte_CRC(SYS_CTRL2,0X43);	//0100,0011	 C-ON/D-ON
		}
		else{
		IIC1_write_one_byte_CRC(SYS_CTRL2,0X41);	//0100,0001  C-ON/D-OFF
		}
}
	
/**************************************************************************
Description	:Get the state of BQ76920. 
Remark			:#define SYS_CTRL2 0x05
Date				:21/07/26 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/ 
 void Only_Close_CHG(void)
	{
		BMS_STA();
		if(DSG_STA!=0)
		{
	    IIC1_write_one_byte_CRC(SYS_CTRL2,0X42);	
		}
		else
		{IIC1_write_one_byte_CRC(SYS_CTRL2,0X40);	}
	}

/**************************************************************************
Description	:Get the state of BQ76920. 
Remark			:#define SYS_CTRL2 0x05
Date				:21/07/26 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/ 	
	void Only_Open_DSG(void)
	{
		BMS_STA();
		if(CHG_STA!=0)
		{
	    IIC1_write_one_byte_CRC(SYS_CTRL2,0X43);	
		}
		else
		{IIC1_write_one_byte_CRC(SYS_CTRL2,0X42);}	
	}


/**************************************************************************
Description	:Get the state of BQ76920. 
Remark			:#define SYS_CTRL2 0x05
Date				:21/07/26 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/ 	
  void Only_Close_DSG(void)
	{
		BMS_STA();
		if(CHG_STA!=0)
		{
	    IIC1_write_one_byte_CRC(SYS_CTRL2,0X41);	
		}
		else
		{IIC1_write_one_byte_CRC(SYS_CTRL2,0X40);	}
	}

/**************************************************************************
Description	:Open C&D-FET.
Remark			:#define SYS_CTRL2 0x05
Date				:21/07/28 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/ 	
void Open_DSG_CHG(void){
	
	IIC1_write_one_byte_CRC(SYS_CTRL2,0X43); //0100 0011

}

/**************************************************************************
Description	:Close C&D-FET. 
Remark			:#define SYS_CTRL2 0x05
Date				:21/07/28 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/ 	
 void Close_DSG_CHG(void)
	{
	 IIC1_write_one_byte_CRC(SYS_CTRL2,0X40);	  //0100 0000
	}

/**************************************************************************
Description	:Update DATA Of The Battery. 
Remark			:The first  recall function , form Main() 
Date				:21/05/19 DW
Update			:
Copyright		:All right reserved by DengWei.
**************************************************************************/ 
 void Get_Update_Data(void)
{	  
    Get_Battery1(); //Get the Cell information
    Get_Battery2();
	  Get_Battery5();
     	
		Get_Update_ALL_Data();//�ܵ�ѹ
	  Get_SOC();						//RSOC
		Get_Temp_FromAFE();			//Get the tempereture of cells
    Get_BQ_Current();			//Current on SR
    BMS_STA();						//get State of BMS
		Update_val();			    //AFE anolgy value of CELLS
}



 int OT_Alarm_flag,UT_Alarm_flag;


 void Temp_ALERT(void)
{
	   Get_Temp_FromAFE();
	 
	if((Temperature > OTPThreshold))	//Over 60�� 
	  {		
		OT_Alarm_flag = 1;	//high tempereture alarm 
	  }
	else OT_Alarm_flag = 0;  //UTPThreshold = -20��
		
	//UTPThreshold = -20��; TempPThreshold = -50 					
	if((TempPThreshold<Temperature && Temperature < UTPThreshold))   // From -50 TO -20
		{
		UT_Alarm_flag = 1;	//Low tempereture alarm 			
		}
	else UT_Alarm_flag = 0;
							
 }
 
/****************************************
fuction:void readbqstate(void)
description:��ȡ�����ź�ֵ
Parameters: UV_Alarm_flag�OOV_Alarm_flag
            SCD_Alarm_flag,OCD_Alarm_flag
******************************************/

 int UV_Alarm_flag,OV_Alarm_flag,SCD_Alarm_flag,OCD_Alarm_flag;
 
 
void ALERT_1_Recognition(void)
{
	
  unsigned char sys_stat_1,UV_1,OV_1,UV_2,OV_2,SCD,OCD;//sys_stat_2,
  sys_stat_1 = IIC1_read_one_byte(SYS_STAT);//��ȡ״̬
  UV_1  =  sys_stat_1&0x08;  //ȡ��UVλ
  OV_1  =  sys_stat_1&0x04;
  SCD   =  sys_stat_1&0x02;
  OCD   =  sys_stat_1&0x01;
  if((UV_1 == 0x08)||(UV_2 == 0x08))
  {
      UV_Alarm_flag = 1;    //Ƿѹ����
		  printf("pack UV\n");
  }	
   else
     UV_Alarm_flag = 0;     //û��Ƿѹ
     if((OV_1 == 0x04)||(OV_2 == 0x04))
      {
       OV_Alarm_flag = 1;			 
		   printf("pack OV\n");
      }
        else
           OV_Alarm_flag = 0;
      if(SCD == 0x02)
				{
				SCD_Alarm_flag = 1;
				printf("pack SCD\n");		
				}
			else
				SCD_Alarm_flag = 0;

			if(OCD == 0x01)
				{
					OCD_Alarm_flag = 1;
					printf("pack OCD\n");		
				}   
			else
					OCD_Alarm_flag = 0;	
}





int i,max,min,OV_T,UV_T,OT_T,UT_T;
void Led_Alarm(void)
{
	
    if(UV_Alarm_flag == 1)
		     {
           delay_ms(200);
					 UV_T=1;
           UV_Alarm_flag = 0;
           IIC1_write_one_byte_CRC(SYS_STAT,0xFF);
		 
		     }
		else
			if(UV_T==1)
			{
				min = Battery_Value[0];
				for(i = 0; i<20 ;i++)
					if( Battery_Value[i] < min )
						 min = Battery_Value[i];
							if( min > UV_Re_Threshold)
							{
								IIC1_write_one_byte_CRC(SYS_STAT,0xFF);           		
								Open_DSG_CHG();
								delay_ms(500);
							  UV_T=0;
							}
			}	  

							
							if(OV_Alarm_flag == 1)
								{
									delay_ms(200);									
									OV_T=1;
                  OV_Alarm_flag = 0;
                  IIC1_write_one_byte_CRC(SYS_STAT,0xFF);
               						
								}
								else
									if(OV_T == 1 )
									{
									  max = Battery_Value[0];
									  for(i = 0; i<20 ;i++)
								       if(Battery_Value[i]>max )
												  max = Battery_Value[i];
									         if( max < OV_Re_Threshold)
													 {
														 IIC1_write_one_byte_CRC(SYS_STAT,0xFF);
                          											 												 
										         Open_DSG_CHG();
														 delay_ms(500);
														 OV_T=0;
													 }
													   
									 }			   
									      
									 if(SCD_Alarm_flag == 1)
										{
											delay_ms(5000);
																								
                      IIC1_write_one_byte_CRC(SYS_STAT,0xFF);               	
										  Open_DSG_CHG();
											SCD_Alarm_flag =0;
										} 											
											 if(OCD_Alarm_flag == 1)
												{
													delay_ms(5000);											
													IIC1_write_one_byte_CRC(SYS_STAT,0xFF);
	
										      Open_DSG_CHG();
                          OCD_Alarm_flag =0;													
												}
		
													if(OT_Alarm_flag == 1)
													 {

														 delay_ms(200);								
														 OT_T=1;
														 Close_DSG_CHG();																											 
													 }
													   else 
															   if(OT_T == 1)
																   {																	 
																    Open_DSG_CHG();																 
																    OT_T =0;
																    }
													 													    
															 if(UT_Alarm_flag == 1)
															 {
																 delay_ms(200);

																 UT_T=1;
																 Close_DSG_CHG();                                 																 
															 }
															 else 
																   if( UT_T==1)
																			{
																			Open_DSG_CHG();
																			UT_T=0;
																			}
															 
															     
				
				
}

