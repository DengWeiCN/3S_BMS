#include "Command.h"
#include "timer.h"
#include "BQ76920.h"
#include "IO_CTRL.h"


#define Status1  1 //Battery Alone mode.
#define Status2  2 //Operating mode.
#define Status3  3 //Shipmode mode, After wake up from shipmode, Change to Normal mode.


unsigned char Current_Battery_Status = 1; //The Current status of the battery switching FLAG.

extern char Have_Charge_Voltage;//A flag of Chrger in/out
extern char DET_Pin;//use a Pin to check the System or Charger in/out.
extern int Battery_Value[50];//Battery Information
extern  int OT_Alarm_flag,UT_Alarm_flag;
extern int Count,Due_Count,One_Second_Flag;
extern int UV_Alarm_flag,OV_Alarm_flag,SCD_Alarm_flag,OCD_Alarm_flag;
extern int NO_Current_15min_Flag;



void Battery_Switching_Command(void)
{ 

		Temp_ALERT();    	//Read Tempreature of CELL.
		ALERT_1_Recognition();//read out Alart information of AFE.
	//Charger_Detection();//Get Charger  flag.
		DET_Pin_Flag();   //Get DET Pin flag.
	
	switch(Current_Battery_Status)
	{	
		case Status1://1---->At Battery Alone mode, Battery wake up and C/D-FET OFF
								if(Battery_Value[32]!=0)  //rsoc��Ϊ0
									{	//System Not in OR Charger Not in OR Over Discharge.
										if(DET_Pin==1||Have_Charge_Voltage==0||UV_Alarm_flag==1) 
											{	
												Close_DSG_CHG(); //Close C/D-FET
												Current_Battery_Status=Status1; //Kepp in this mode.
											}else if(DET_Pin==0||Have_Charge_Voltage==1||UV_Alarm_flag==0)//System in OR Charger in OR Not Over Discharge. 
											{
											Current_Battery_Status=Status2; //turned into Operating mode.
											}
									}else if(Battery_Value[32]==0) //Don't need judge DET-pin+ODP at this situation. RSOC=0
											{
											if(Have_Charge_Voltage==1) //Charger Not in.------>
											{	
												Current_Battery_Status=Status3;//Turned into Ship mode.
											}
											else if(Have_Charge_Voltage==1)//Charger in.
											{
												Current_Battery_Status=Status2;//Turned into Operating mode.
											}
													
											}
								break;
		
		
		case Status2://2---->Operating mode.
								if(DET_Pin==1||Have_Charge_Voltage==0||UV_Alarm_flag==0)//------>
								{											
												if(OT_Alarm_flag==1)//Over temp.
												{
													Only_Close_CHG(); //Close C-FET
												//Close_DSG_CHG();	//Close C/D-FET
												}else if(UT_Alarm_flag==1) //Under Temp. 
												{								
													Only_Close_DSG();  //Close D-FET
												}else if(OT_Alarm_flag==0&&UT_Alarm_flag==0) //None of these happened.
												{
													Open_DSG_CHG();   //Open C/D-FET
												}
																			
									if(NO_Current_15min_Flag==1||UV_Alarm_flag==1) //No current for 15min or ODP Happened.
										{
												Current_Battery_Status=Status3;		//turned into Ship mode.										
										}
									else {Current_Battery_Status=Status2;}
												
								}else {Current_Battery_Status=Status1;	}	//Enter status1 if not satisfied status2 condition.
													
								//Current_Battery_Status = Status1;
                break;

		case Status3://3---->Ship mode.
								if(Have_Charge_Voltage==0&&One_Second_Flag==3) //Charger in.------>
								{
									Wake_Up_AFE();
									One_Second_Flag=0;//Clear flag
									Current_Battery_Status=Status2;								
								}else 
									{
									Switch_To_Ship_Mode();	
									Current_Battery_Status=Status3;
									}						
								break;
		
		default : 	
								break;

	}
}



