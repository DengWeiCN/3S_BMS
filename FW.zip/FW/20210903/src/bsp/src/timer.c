
//header of the timer 

#include "wdg.h"
#include "timer.h"
#include "led.h"
#include "usart.h"
#include "BQ76920.h"
#include "Command.h"

//Timer2 and Timer3
//Frequency is 72M
//arr��Auto Reload value
//psc��

u8 cnt1=0;
u8 cnt2=0;
u8 open,close;
int Due_Count,One_Second_Flag=0;
int Timer_250mS_Flag =0;
int NO_Current_15min_Flag=0;
extern unsigned char Current_Battery_Status;
extern int Battery_Value[50];

 
void TimerNvic_Config(void)
{ 	
    NVIC_InitTypeDef	NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 		
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn; 		
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 	 
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;      
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;       
    NVIC_Init(&NVIC_InitStructure);                         
	
	  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	  NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn; 		
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2; 
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;     
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;         
    NVIC_Init(&NVIC_InitStructure);                      
	
}



void TIM2_Config(u16 arr,u16 psc)
{
 //T=(TIM_Period+1)*(TIM_Prescaler+1)/TIMxCLK
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE); 
  TIM_DeInit( TIM2);
  TIM_InternalClockConfig(TIM2);
  //��ʱ��TIM2��ʼ��
  TIM_TimeBaseStructure.TIM_Period = arr; //9999
  TIM_TimeBaseStructure.TIM_Prescaler =psc; //7199
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure); 
  TIM_ClearFlag(TIM2, TIM_FLAG_Update);
  TIM_ARRPreloadConfig(TIM2, DISABLE);

  TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE ); 
  TIM_Cmd(TIM2,ENABLE);        
  TimerNvic_Config();
}



//Timer2 Interrupt Handle Function, get into this every 1000mS.
void TIM2_IRQHandler(void)  
{    
		if( TIM_GetITStatus( TIM2, TIM_IT_Update ) != RESET )	
		{
			TIM_ClearITPendingBit(TIM2, TIM_IT_Update); 
			//UartSend("1000mS----\r\n");		
			One_Second_Flag++;


		}					
}						
	



void TIM3_Config(u16 arr,u16 psc)
{
 //Fumula of timer count��T=(TIM_Period+1)*(TIM_Prescaler+1)/TIMxCLK
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); 
  TIM_DeInit( TIM3);		//Reset timer3's initial value
  TIM_InternalClockConfig(TIM3);
 
  TIM_TimeBaseStructure.TIM_Period = arr; 
  TIM_TimeBaseStructure.TIM_Prescaler =psc; 
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); 
/*Clear flag, in case the Interrupt occur at the fist time.*/
  TIM_ClearFlag(TIM3, TIM_FLAG_Update);   
  TIM_ARRPreloadConfig(TIM3, DISABLE);

  TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE ); 
  TIM_Cmd(TIM3, ENABLE);  
}


//timer3 Interrupt every 250mS
void TIM3_IRQHandler(void)   
{   
  if( TIM_GetITStatus( TIM3, TIM_IT_Update ) != RESET )	
	{
	  TIM_ClearITPendingBit(TIM3, TIM_IT_Update);  
		Timer_250mS_Flag++; 
							
    if(Timer_250mS_Flag>1){
		Timer_250mS_Flag=0;
		} 			
	}  
}





