/****************************************************************************************************************************/
/*  Filename    : systick.h                                                                             								        */
/*  Component name : 3S_BMS                                                                                                 */
/*  Abstract    : Header file for external                                                                                  */
/*  Copyright(C): 2021 by DW                                                                           										  */
/*  Author      : DengWei                                                                                                   */
/*  Revision    : 00.01                                                                                                     */
/*  Revision history : 00.01 | 2021/02/08 | First Release                                                                		*/
/*                   : 01.00 | 2021/xx/xx |                                                                   					    */
/*                   : 02.00 | 2021/xx/xx |                                                                                 */
/*                   : 02.01 | 2021/xx/xx |                                                                                 */
/*                   : 03.00 | 2021/xx/xx |                                                                                 */
/*  Date of creation : 2021/04/04                                                                                           */
/*     Last modified : 2021/04/04                                                                                           */
/****************************************************************************************************************************/
#include "SYSTICK.h"

extern u16 nTime;

 /**
  * @file   SYSTICK_Init
  * @brief  ��ʼ��SYSTICK��1us�ж�1��
  * @param  ��
  * @retval ��
  */
void SYSTICK_Init(void)
{	
/*SystemCoreClock/ 1000000��1us�ж�1�Σ�SystemCoreClock/ 1000��1ms�ж�һ��*/	
  while (SysTick_Config(SystemCoreClock/1000000));
}

 /**
  * @file   delay_us
  * @brief  ΢����ʱ
  * @param  ��ʱʱ��
  * @retval ��
  */
void delay_us(u16 nus)
{
  nTime=nus;
  while(nTime);
}

 /**
  * @file   delay_ms
  * @brief  ������ʱ
  * @param  ��ʱʱ��
  * @retval ��
  */
void delay_ms(u16 nms)
{
  while(nms--)
  delay_us(1000);
}

