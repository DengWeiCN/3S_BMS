/********************************************************************************************************
**                      
**------------------------------------------------------------------------------------------------------
** �ļ�: system.h 
** �汾: v1.0
**------------------------------------------------------------------------------------------------------
** ����:
**      ϵͳ�ĳ�ʼ��
**------------------------------------------------------------------------------------------------------
********************************************************************************************************/
#ifndef __SYSINIT__H__
#define __SYSINIT__H__

//----------------------------------------------------------------
//��������ͷ�ļ�  
#include "stm32f10x.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdarg.h>
#include <math.h>
#include "bsp_systick.h"
	
//---------------------------------------------------------------
//����������Ӧ��ͷ�ļ�
#include "bsp_usart.h"
#include "bsp_led.h"
#include "bsp_key.h"
#include "bsp_exit.h"
#include "bsp_adc.h"
#include "bsp_dac.h"
#include "bsp_dma.h"	
#include "bsp_tft_lcd.h"
#include "bsp_spi.h"
#include "bsp_spi_en25qxx.h"
#include "bsp_stm32_flash.h"
#include "bsp_sram.h"
#include "bsp_spi_sd.h"
#include "bsp_timer.h"
#include "bsp_iwdg.h"
#include "bsp_wake_up.h"
#include "bsp_rtc.h"
#include "bsp_i2c_gpio.h"
#include "bsp_eeprom_24xx.h"
#include "bsp_ds18B20.h"
#include "bsp_infrare.h"

//λ������,ʵ��51���Ƶ�GPIO���ƹ���
//����ʵ��˼��,�ο�<<CM3Ȩ��ָ��>>������(87ҳ~92ҳ).
//IO�ڲ����궨��
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
//IO�ڵ�ַӳ��
#define GPIOA_ODR_Addr    (GPIOA_BASE+12) //0x4001080C 
#define GPIOB_ODR_Addr    (GPIOB_BASE+12) //0x40010C0C 
#define GPIOC_ODR_Addr    (GPIOC_BASE+12) //0x4001100C 
#define GPIOD_ODR_Addr    (GPIOD_BASE+12) //0x4001140C 
#define GPIOE_ODR_Addr    (GPIOE_BASE+12) //0x4001180C 
#define GPIOF_ODR_Addr    (GPIOF_BASE+12) //0x40011A0C    
#define GPIOG_ODR_Addr    (GPIOG_BASE+12) //0x40011E0C    

#define GPIOA_IDR_Addr    (GPIOA_BASE+8) //0x40010808 
#define GPIOB_IDR_Addr    (GPIOB_BASE+8) //0x40010C08 
#define GPIOC_IDR_Addr    (GPIOC_BASE+8) //0x40011008 
#define GPIOD_IDR_Addr    (GPIOD_BASE+8) //0x40011408 
#define GPIOE_IDR_Addr    (GPIOE_BASE+8) //0x40011808 
#define GPIOF_IDR_Addr    (GPIOF_BASE+8) //0x40011A08 
#define GPIOG_IDR_Addr    (GPIOG_BASE+8) //0x40011E08 
 
//IO�ڲ���,ֻ�Ե�һ��IO��!
//ȷ��n��ֵС��16!
#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)  //��� 
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n)  //���� 

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)  //��� 
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n)  //���� 

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)  //��� 
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)  //���� 

#define PDout(n)   BIT_ADDR(GPIOD_ODR_Addr,n)  //��� 
#define PDin(n)    BIT_ADDR(GPIOD_IDR_Addr,n)  //���� 

#define PEout(n)   BIT_ADDR(GPIOE_ODR_Addr,n)  //��� 
#define PEin(n)    BIT_ADDR(GPIOE_IDR_Addr,n)  //����

#define PFout(n)   BIT_ADDR(GPIOF_ODR_Addr,n)  //��� 
#define PFin(n)    BIT_ADDR(GPIOF_IDR_Addr,n)  //����

#define PGout(n)   BIT_ADDR(GPIOG_ODR_Addr,n)  //��� 
#define PGin(n)    BIT_ADDR(GPIOG_IDR_Addr,n)  //����

// ���ⲿ�ļ����õ�ȫ�ֱ���������
extern float OutData[4];  	  // ���ڲ�������ʾ����Serial Digital Scope
extern char *send_str;	 	  // ���ڲ���Usart_Dma
extern uint16_t adc_dma_value;  // ���ڲ���Adc_Dma

//----------------------------------------------------------------
// �궨��
#define Usart1_Dma1_Init()			DMA1_Init(DMA1_Channel4, 						\
												DMA_DIR_PeripheralDST, 				\
												(u32)&USART1->DR, 					\
												(u32)send_str, 						\
												strlen(send_str), 					\
												DMA_PeripheralDataSize_Byte,		\
												DMA_MemoryDataSize_Byte,			\
												DMA_Mode_Normal)					\
												
#define Adc1_Dma1_Init()			DMA1_Init(DMA1_Channel1, 						\
												DMA_DIR_PeripheralSRC, 				\
												(u32)&ADC1->DR, 					\
												(u32)&adc_dma_value, 				\
												sizeof(u16), 						\
												DMA_PeripheralDataSize_HalfWord,	\
												DMA_MemoryDataSize_HalfWord,		\
												DMA_Mode_Circular)					\

//----------------------------------------------------------------
//�ⲿ�������������ļ�����
void SysInit(void);		// �ϵ��ʼ��
void OutPut_Data(void);	// ������ʾ�����������
				
#endif

/********************************************************************************************************
**                            End Of File
********************************************************************************************************/

