#ifndef __ADC_H
#define __ADC_H	

void Adc_Init(void);
int  Get_Adc(char ch); 
int Get_Adc_Average(char ch,char times); 
void Charger_Detection(void);

#endif 
