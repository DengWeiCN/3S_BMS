#ifndef __Command_H
#define __Command_H
#include "stm32f10x.h"


void Battery_Switching_Command(void);

#endif


